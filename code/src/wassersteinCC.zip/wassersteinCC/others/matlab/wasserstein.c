/* wassermat.c: MATLAB bindings for the calculation of Wasserstein distances

   Copyright (C) 2010 Michael Muskulus (E-mail: michael.muskulus@ntnu.no)
  
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <mex.h>
#include "solve.h"
#include <string.h>
#include <stdlib.h>

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  /* nlhs: no. left hand side arguments (1)
     plhs: output pointers
     nrhs: no, righ hand side arguments
     prhs: input pointers
  */
  bool use_weights = false;
  double td = -1.0; /* for fun */
  /* check options */
  int argi = 0;
  int k;
  g_torus   = false;
  g_verbose = false;
  g_order   = 1.0;
  /* mexPrintf("Checking arguments...\n"); 
     fflush(stdout); */
  while (argi < nrhs) {
    if (mxIsChar(prhs[argi])) {
      int len = (mxGetM(prhs[argi]) * mxGetN(prhs[argi])) + 1;
      char* buf = mxCalloc(len+1, sizeof(char));
      buf = mxArrayToString(prhs[argi]);
      buf[len] = 0;
      /* mexPrintf("Got option string %s\n",buf); */
      if (buf[0] != '-') mexErrMsgTxt("All options need to begin with '-'");
      switch(buf[1]) {
      case 't': g_torus = true; 
	if (g_verbose) mexPrintf("Using torus distances\n");
	break;
      case 'p': 
	if (buf[2] != ' ') mexErrMsgTxt("Need space before order");
        /* mexPrintf("len = %i\n",strlen(buf)); */
	if (len < 3) mexErrMsgTxt("Could not determine order");
	/* mexPrintf("remain = %s\n", &buf[2]); */
	g_order = atof(&buf[2]); 
	/* mexPrintf("Order = %f\n",g_order); */
	if (g_order < 1.0) mexErrMsgTxt("Invalid order selected, needs to be >= 1.0");
	break;
      case 'v': g_verbose = 1;
	if (len > 3 && buf[2] == 'v') g_verbose = 2;
	break;
      default: mexErrMsgTxt("Unknown option selected");
      };
      --nrhs;
      for (k=argi; k<nrhs; ++k) prhs[k] = prhs[k+1];
      --argi;
    };
    ++argi;
  };
  /* mexPrintf("No. arguments now = %i\n",nrhs); */
  if (g_verbose) {
    mexPrintf("Starting up...\n");
    mexEvalString("drawnow;");
  };
  if (nrhs < 2) mexErrMsgTxt("Need at least two input matrices");
  if (nlhs > 1) mexErrMsgTxt("Has at most one output");
  if (nrhs != 2 && nrhs != 4) mexErrMsgTxt("Strange number of arguments (should be either 2 or 4) -- see help('wasserstein')");
  int status;
  const mxArray *xData = prhs[0]; /* need to be transposed */
  const mxArray *yData = prhs[1]; 
  const mxArray* wxData;
  const mxArray* wyData;
  double* wx = NULL;
  double* wy = NULL;
  int nx      = mxGetM(xData);
  int colLenx = mxGetN(xData);
  int ny      = mxGetM(yData);
  int colLeny = mxGetN(yData);
  double *x1  = mxGetPr(xData);
  double *y1  = mxGetPr(yData);
  double *x   = malloc(nx*colLenx*sizeof(double));
  double *y   = malloc(ny*colLeny*sizeof(double));
  if (x == NULL) mexErrMsgTxt("Memory problem");
  if (y == NULL) mexErrMsgTxt("Memory problem");
  int *wxi;
  int *wyi;
  int i,j;
  if (colLenx != colLeny) mexErrMsgTxt("Different no. coordinates (columns) of point sets not allowed");
  k = 0; for (i=0; i<nx; ++i) for (j=0; j<colLenx; ++j) x[k++] = x1[i+j*nx]; 
  k = 0; for (i=0; i<ny; ++i) for (j=0; j<colLeny; ++j) y[k++] = y1[i+j*ny]; 
  /* parse options */
  g_dim = colLenx;
  /* nlhs contains remaining matrices */
  if (nrhs == 4) {  /* weights */
    use_weights = true;
    wxData = prhs[2];
    wyData = prhs[3];
    wx = mxGetPr(wxData);
    wy = mxGetPr(wyData);
  } else {
    use_weights = false;
    wx = malloc(nx*sizeof(double));
    wy = malloc(ny*sizeof(double));
    for (i=0; i<nx; ++i) wx[i] = 1.0 / (double) nx;    
    for (i=0; i<ny; ++i) wy[i] = 1.0 / (double) ny;
  };
  /* calculation */
  if (nx == ny && !use_weights && false) {
    wxi = malloc(nx*sizeof(int));
    wyi = malloc(ny*sizeof(int));
    for (i=0; i<nx; ++i) wxi[i] = 1;    
    for (i=0; i<ny; ++i) wyi[i] = 1;
    if (g_verbose) mexPrintf("Using integer-arithmetic...\n");
    if (g_verbose) mexPrintf("Dimension = %i\n",g_dim);
    td = solve_gplk_int(g_dim,nx,x,wxi,ny,y,wyi,1e5,g_verbose);
    free(wxi);
    free(wyi);
  } else {
    if (g_verbose) {
      mexPrintf("Dimension = %i\n",g_dim);
      mexPrintf("Running the problem...\n");
      mexEvalString("drawnow;");
    };
    td = solve_gplk(g_dim,nx,x,wx,ny,y,wy,g_verbose);
  };
  /* simple output (no bootstrapping) */
  int colLen = 1; 
  int rowLen = 1;
  plhs[0] = mxCreateDoubleMatrix(colLen,rowLen,mxREAL);
  double *out = mxGetPr(plhs[0]);
  out[0] = td;
  if (!use_weights) {
    free(wx);
    free(wy);
  };
  free(x);
  free(y);
  return;
};



