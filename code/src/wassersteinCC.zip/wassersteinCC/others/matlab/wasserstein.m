% WASSERSTEIN
%   Calculate Wasserstein distance for two (weighted) point sets
% 
% SYNTAX
%   td = wasserstein(x,y)
%   td = wasserstein(x,y,wx,wy)
%
% OUTPUT
%   td  - Wasserstein distance
%
% OPTIONS
%   '-p ORDER' -- Wasserstein distance of order 'ORDER' (default: 1.0)
%   '-t'       -- Wrap distances (0 <= data <= 2*pi)
%   '-v'       -- Verbose output (calculation details)
%   '-vv'      -- Extremely verbose output 
%
% INPUT
%   x,y   - Matrices with points per row (coordinates in columns)
%   wx,wy - Vectors with weights per point (probability mass)
%
% DETAILS
%   see the documentation of the stand-alone file 'wasserstein'
%
% EXAMPLES
%   wasserstein(x,y,'-t')      -- Calculate distance between phase distributions
%   wasserstein(x,y,'-p 2.0')  -- Calculate distance of order 2 (quadratic)
%
% REFERENCES
%   The theory behind the Wasserstein distances can be found in:
%      - Villani C: Topics in optimal transportation. 
%        American Mathematical Society (2003).
%   The following articles consider its application to time series and to phase distributions:
%      - Muskulus M, Verduyn-Lunel S:
%        Wasserstein distances in the analysis of time series and dynamical systems. 
%        Physica D (2010), to appear.
%      - Muskulus M, Houweling S, Verduyn-Lunel S, Daffertshofer A:
%        Functional similarities and distance properties. 
%        J Neurosci Meth 183 (2009), 31-31.
%
% COPYRIGHT (C) 2010 Michael Muskulus (michael.muskulus@ntnu.no)

