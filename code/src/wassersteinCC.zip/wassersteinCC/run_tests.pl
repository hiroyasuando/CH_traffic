#!/usr/bin/perl

sub equal {
  my ($A, $B, $tol) = @_;
  return sprintf("%.${tol}g", $A) eq sprintf("%.${tol}g", $B);
}

$tol = 4; # 1e-4

$i = 1;
print "Running test no. " . $i++;
$res = `./wasserstein -f tests/t001x tests/t001y`;
chomp($res);
(equal($res,1.25,$tol)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

print "Running test no. " . $i++;
$res = `./wasserstein -f -w tests/t002x tests/t002y`;
chomp($res);
(equal($res,0.6,$tol)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

print "Running test no. " . $i++;
$res = `./wasserstein -d l1 tests/t003x tests/t003y`;
chomp($res);
(equal($res,6,$tol)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

print "Running test no. " . $i++;
$res = `./wasserstein -d l2 tests/t003x tests/t003y`;
chomp($res);
(equal($res,sqrt(20),$tol)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

print "Running test no. " . $i++;
$res = `./wasserstein tests/t005x tests/t005y`;
chomp($res);
(equal($res,0.722,3)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

print "Running test no. " . $i++;
$res = `./wasserstein  -e 2 -f tests/t005x tests/t005y`;
chomp($res);
(equal($res,1.67,2)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

print "Running test no. " . $i++;
$res = `./wasserstein -e 2 -l 2 tests/t005x tests/t005y`;
chomp($res);
(equal($res,1.429,3)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

print "Running test no. " . $i++;
$res = `./wasserstein -d l1 -e 3 -l 2 tests/t005x tests/t005y`;
chomp($res);
(equal($res,4.000,3)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

print "Running test no. " . $i++;
$res = `./wasserstein  -d l1 -e 3 -l 2 -p 2 tests/t005x tests/t005y`;
chomp($res);
(equal($res,4.3359,3)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

print "Running test no. " . $i++;
$res = `./wasserstein -d l2 -p 2 -e 3 -l 2 -f tests/t005x tests/t005y`;
chomp($res);
(equal($res,3.1144,3)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

print "Running test no. " . $i++;
# oops
$res = `./wasserstein -d l2 -p 2 -e 3 -l 2 tests/t005x tests/t005y`;
chomp($res);
(equal($res,3.1144,3)) or die("\nERROR: Test failed (wrong results: " . $res . "; expected 3.1144)");
print " (ok)\n";

print "Running test no. " . $i++;
$res = `./wasserstein -e 2 -l 3 -f tests/t004x tests/t004y`;
chomp($res);
(equal($res,1.8758,4)) or die("\nERROR: Test failed (wrong results: " . $res . ")");
print " (ok)\n";

