/* solve.cc: Solver interface
  
   Copyright (C) 2010 Michael Muskulus (E-mail: michael.muskulus@ntnu.no)
  
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "solve.h"
#include <glpk.h>

#include <iostream>
#include <sstream>
#include <string>
#include <cassert>        // assert 
#include <cmath>          // fabs
#include <cfloat>         // DBL_MAX
#include <climits>        // INT_MAX
#include <stdlib.h>       // exit
#include <stdio.h>        // printf

using namespace std;

int g_write_dimacs       = false;    /* option -a */
char* g_dfile;                       /*   corresponding file */
int g_bootstrap          = false;    /* option -b */
int g_ncalc              = 1;        /*   no. calculations / bootstraps to run */
enum distance_t g_distance = dist_l2; /* option -d */
int g_use_embedding      = false;    /* option -e */
int g_edim               = -1;       /*   corresponding embedding dimension */
int g_elag               = 1;        /*   corresponding time lag (option -l) */
int g_integer_arithmetic = true;     /* option -f */
int g_output_mean        = false;    /* option -m */
double g_order           = 1.0;      /* option -p */
int g_random_seed        = false;    /* option -r */
int g_resample           = false;    /* option -s */
int g_ssize              = 0;        /*   corresponding sample size */
int g_torus              = false;    /* option -t */
int g_verbose            = false;    /* option -v */
int g_use_weights        = false;    /* option -w */
double g_scaling         = 1e5;
int g_digits             = 5;
int g_dim = 0;                       /* dimension of space in which points live */

string s_err;

//
// show_error
//

int show_error(const char* what) {
  printf("Error: %s\n",what);
  exit(1);
  return 1;
};

//
// get_distance
//

double get_distance(int dim, int i, double* x, int j, double* y) {
  int k;
  double s = 0.0;
  double d1; // one-dimensional distance
  double d2;
  for (k=0; k<dim; ++k) {  // component-wise
    d1 = fabs(x[i*dim+k]-y[j*dim+k]);
    if (g_torus) {
      d2 = 2.0*M_PI - d1;
      d1 = fmin(d1,d2);
    };
    switch(g_distance) {
    case dist_l1 : s += d1; break;
    case dist_l2 : s += d1*d1; break;
    case dist_max: s = fmax(d1,s); break;
    default: show_error("Unknown distance (internal error)");
    };
  };
  switch(g_distance) {
  case dist_l1 : break;
  case dist_l2 : s = sqrt(s); break; 
  case dist_max: break;
  default: show_error("Unknown distance (internal error)");
  };
  s = pow(s, g_order);
  // if (g_torus) cout << "torus dst = " << s << " in dim = " << dim << endl;
  return s;
};

//
// solve_gplk
//

extern "C" double solve_gplk(int dim, int nx, double* x, double* wx, int ny, double *y, double* wy, int verbose) {
  // typedef struct { double rhs; } v_data;
  // typedef struct { double low, cap, cost; } a_data;
  typedef struct { double rhs; } v_data;
  typedef struct { double cap, cost; } a_data;
  v_data* v_ptr;
  a_data* a_ptr;
  glp_graph *G;
  glp_prob *lp;
  glp_arc* arc;
  glp_vertex* vertex;
  int i,j;
  double td; // result
  G = glp_create_graph(sizeof(v_data), sizeof(a_data)); // empty problem graph
  // scale weights
  if (verbose) cout << endl << "Normalizing probabilities..." << endl;
  cout.flush();
  double mass = 0.0;
  for (i=0; i<nx; ++i) mass += wx[i];
  for (i=0; i<nx; ++i) wx[i] /= mass;
  mass = 0.0;
  for (j=0; j<ny; ++j) mass += wy[j];
  for (j=0; j<ny; ++j) wy[j] /= mass;
  mass = 0.0;
  // construct minimum-cost-flow graph
  glp_add_vertices(G, nx + ny);
  glp_vertex** vertex_list = G->v;
  // enter additional vertex data
  if (verbose) cout << "Entering vertices..." << endl;
  cout.flush();
  for (i=1; i<=nx; ++i) {
    vertex = vertex_list[i];
    v_ptr = (v_data*) vertex->data;
    v_ptr->rhs = wx[i-1];  // set mass
    if (verbose > 1) cout << "Vertex 1-" << i << " initialized with mass = " << v_ptr->rhs << endl;
    mass += v_ptr->rhs;
  };
  for (j=1; j<=ny; ++j) {
    vertex = vertex_list[nx+j];
    v_ptr = (v_data*) vertex->data;
    v_ptr->rhs = -wy[j-1];  // set mass; CAVEAT: sign
    if (verbose > 1) cout << "Vertex 2-" << j << " initialized with mass = " << v_ptr->rhs << endl;
    mass += v_ptr->rhs;
  };
  if (fabs(mass) > sqrt(DBL_EPSILON)) {
    stringstream istr;
    istr << mass;
    s_err = "Masses do not match -- Non-negligible imbalance = " + istr.str();
    show_error(s_err.c_str());
  };
  // enter arcs
  if (verbose) cout << "Calculating all distances..." << endl;
  cout.flush();
  for (i=1; i<=nx; ++i) { // CAVEAT: indexing starts at 1
    for (j=1; j<=ny; ++j) {
      arc = glp_add_arc(G,i,nx +j );
      a_ptr       = (a_data*) arc->data;
      a_ptr->cost = get_distance(dim,i-1,x,j-1,y);
      a_ptr->cap  = DBL_MAX; // CAVEAT: default is 1.0
      if (verbose > 1) cout << "Distance between 1-" << i << " and 2-" << j << " is " << a_ptr->cost << endl;
    };
  };
  // sanity checks
  assert(G->nv == int(nx + ny));
  assert(G->na == int(nx*(ny)));
  // convert to LP
  if (verbose) cout << "Converting to LP problem..." << endl;
  cout.flush();
  lp = glp_create_prob();
  glp_mincost_lp(lp, G, GLP_ON, 
		 offsetof(v_data, rhs), 
		 -1, offsetof(a_data, cap), offsetof(a_data, cost));
  glp_delete_graph(G);
  if (g_write_dimacs) {
    string dfile(g_dfile);
    if (glp_write_lp(lp, NULL, dfile.c_str())) { 
      s_err = "Problem writing DIMACS file " + dfile;
      show_error(s_err.c_str());
    };
  };
  // solve it
  if (verbose) cout << "Solving with floating-point arithmetic..." << endl;
  cout.flush();
  glp_smcp parm;
  glp_init_smcp(&parm);
  parm.presolve = GLP_ON;
  if (!verbose) parm.msg_lev = GLP_MSG_OFF;
  if (verbose) cout << endl;
  if (glp_simplex(lp, &parm)) show_error("Impossible to find solution (numerical instability? bad scaling?)");
  // glp_write_sol(lp, "solution.txt");
  td = glp_get_obj_val(lp);
  td = pow(td, 1/g_order);
  glp_delete_prob(lp);
  return td;
};

//
// solve_gplk_int
//

extern "C" double solve_gplk_int(int dim, int nx, double* x, int* wx, int ny, double *y, int* wy, double scaling, int verbose) {
  // typedef struct { double rhs, pi; } v_data;
  // typedef struct { double low, cap, cost, x; } a_data;
  typedef struct { double rhs, pi; } v_data;
  typedef struct { double cap, cost, x; } a_data;
  v_data* v_ptr;
  a_data* a_ptr;
  glp_graph *G;
  glp_prob *lp;
  glp_arc* arc;
  glp_vertex* vertex;
  int i,j;
  double td; // result
  double loss = 0.0; // from conversion
  G = glp_create_graph(sizeof(v_data), sizeof(a_data)); // empty problem graph
  // construct minimum-cost-flow graph
  glp_add_vertices(G, nx + ny);
  glp_vertex** vertex_list = G->v;
  int mass  = 0;
  // enter additional vertex data
  for (i=1; i<=nx; ++i) {
    vertex = vertex_list[i];
    v_ptr = (v_data*) vertex->data;
    v_ptr->rhs = wx[i-1];  // set mass
    mass += v_ptr->rhs;
    if (verbose > 1) cout << "Vertex 1-" << i << " initialized with mass = " << v_ptr->rhs << endl;
  };
  if (verbose) cout << "Total mass = " << mass << endl;
  int mass1 = mass;
  for (j=1; j<=ny; ++j) {
    vertex = vertex_list[nx+j];
    v_ptr = (v_data*) vertex->data;
    v_ptr->rhs = -wy[j-1];  // set mass
    if (verbose > 1) cout << "Vertex 2-" << j << " initialized with mass = " << v_ptr->rhs << endl;
    mass += v_ptr->rhs;
  };
  if (mass != 0) {
    stringstream istr;
    istr << mass;
    s_err = "Masses do not match -- Non-negligible imbalance = " + istr.str();
    show_error(s_err.c_str());
  };
  // enter arcs
  double maxloss = 0.0;
  for (i=1; i<=nx; ++i) { // CAVEAT: indexing starts at 1
    for (j=1; j<=ny; ++j) {
      arc = glp_add_arc(G,i,nx +j );
      a_ptr       = (a_data*) arc->data;
      double cost = get_distance(dim,i-1,x,j-1,y);
      if ((cost*scaling) >= INT_MAX) show_error("Numerical overflow in scaling distances to integers (use smaller scaling constant or fixed-point arithmetic)");
      if (abs(cost*scaling - int(cost*scaling)) / (cost*scaling) > 1e-3) show_error("Numerical error: loosing too much precision (use larger scaling constant or fixed-point arithmetic)");
      a_ptr->cost = int(cost*scaling);
      maxloss += double(cost*scaling);
      loss += abs(cost*scaling - int(cost*scaling));
      a_ptr->cap  = INT_MAX; // CAVEAT: default is 1.0
      if (verbose > 1) cout << "Distance between 1-" << i << " and 2-" << j << " is " << cost << ", transformed to " << a_ptr->cost << endl;
    };
  };
  if (maxloss > INT_MAX) show_error("Probable numerical overflow (sum of all distances; try to use smaller scaling constant or fixed-point arithmetic");
  // sanity checks
  assert(G->nv == int(nx + ny));
  assert(G->na == int(nx*(ny)));
  // convert to LP for output
  if (g_write_dimacs) {
    lp = glp_create_prob();
    glp_mincost_lp(lp, G, GLP_ON, 
		   offsetof(v_data, rhs), 
		   -1, offsetof(a_data, cap), offsetof(a_data, cost));
    string dfile(g_dfile);
    if (glp_write_lp(lp, NULL, dfile.c_str())) {
      s_err = "Problem writing DIMACS file " + dfile;
      show_error(s_err.c_str());
    };
    glp_delete_prob(lp);
  };
  // solve it
  if (verbose) cout << endl << "Solving with integer arithmetic..." << endl;
  int err = glp_mincost_okalg(G, 
			      offsetof(v_data, rhs), 
			      -1, offsetof(a_data, cap), offsetof(a_data, cost),
			      &td,
			      offsetof(a_data,x), offsetof(v_data, pi));
  if (err) {
    stringstream ss;
    ss << err;
    cout << "GLP_EDATA = " << GLP_EDATA << endl;
    s_err = "Impossible to find integer solution (numerical instability? bad scaling?), error code = " + ss.str();
    show_error(s_err.c_str());
  };
  if (verbose > 1) cout << "raw (integer) TD = " << int(td) << endl; 
  td /= scaling;
  if (verbose > 1) cout << "re-scaled TD     = " << td << endl;
  td /= mass1;
  if (verbose > 1) cout << "re-weighted TD   = " << td << endl;
  td = pow(double(td), 1/g_order);
  if (verbose > 1) cout << "final TD         = " << td << endl;
  glp_delete_graph(G);
  return td;
};

