/* solve.h: Solver interface
  
   Copyright (C) 2010 Michael Muskulus (E-mail: michael.muskulus@ntnu.no)
  
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
  
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#ifndef SOLVE_H
#define SOLVE_H

#ifdef __cplusplus
extern "C" { 
#endif
  
  double solve_gplk(int dim, int nx, double* x, double* wx, int ny, double *y, double* wy, int verbose);
  double solve_gplk_int(int dim, int nx, double* x, int* wx, int ny, double *y, int* wy, double scaling, int verbose);
  double get_distance(int dim, int i, double* x, int j, double* y);
  int show_error(const char* what);
  
#ifdef __cplusplus
} 
#endif

extern int g_write_dimacs;
extern char* g_dfile;
extern int g_bootstrap;
extern int g_ncalc;
extern enum distance_t {dist_l1,dist_l2,dist_max,dist_unknown} g_distance; 
extern int g_use_embedding;
extern int g_edim;
extern int g_elag;
extern int g_integer_arithmetic;
extern int g_output_mean;
extern double g_order;
extern int g_random_seed;
extern int g_resample;
extern int g_ssize;
extern int g_torus;
extern int g_verbose;
extern int g_use_weights;
extern double g_scaling;
extern int g_digits;
extern int g_dim;

#endif

