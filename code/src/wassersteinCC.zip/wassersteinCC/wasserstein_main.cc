// wasserstein.cc: Calculation of Wasserstein distances between two time series
//
// Copyright (C) 2010 Michael Muskulus (E-mail: michael.muskulus@ntnu.no)
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <cassert>        // assert 
#include <cmath>          // fabs
#include <cfloat>         // DBL_MAX
#include <climits>        // INT_MAX

#include <cctype>
#include <ctime>          // time0 (for seeding random number generator)

#include <gsl/gsl_rng.h>  // random number generator

#include <unistd.h>       // getopt
#include <stdlib.h>       // exit

#include "solve.h"

using namespace std;

// 
// global variables
//

string g_fname1;
string g_fname2;

string g_err;

typedef vector<double> point_type;
vector<point_type*> g_list1;         // storage of file contents
vector<point_type*> g_list2;         // storage of file contents
vector<double> g_mass1;              // corresponding point masses
vector<double> g_mass2;              // corresponding point masses

gsl_rng* g_rng;                      // high-quality random number generator

//
// random_int
//

inline int random_int(const int& upperbound) {
  return gsl_rng_uniform_int(g_rng, upperbound);
};

//
// show_help
//

void show_help(int argc, char **argv) {
  cout << "Calculation of Wasserstein distance for two point sets" << endl;
  cout << "Useage:  " << argv[0] << " [-h] [-a DFILE] [-b BSIZE] [-d DST] [-e EDIM [-l ELAG]]" << endl;
  cout << "            [-f] [-i IDIGITS] [-m] [-p ORDER] [-q] [-r] [-s SSIZE] [-t] [-w]" << endl;
  cout << "            FILE1 FILE2" << endl;
  cout << endl;
  cout << "Calculate Wasserstein distances between two multidimensional point sets" << endl;
  cout << endl;
  cout << "Options: " << endl;
  cout << "  -a: Write out the corresponding LP problem in DIMACS format to file \'DFILE\'" << endl;
  cout << "      Note: This does not make sense if bootstrapping" << endl;
  cout << "  -b: Bootstrap the distances BSIZE times" << endl;
  cout << "      Note: if SSIZE is not given, all points will be resampled" << endl;
  cout << "  -d: Use base distance DST (default = l2)" << endl;
  cout << "      Choose one from the following:" << endl;
  cout << "      l1 : Manhattan distance" << endl;
  cout << "      l2 : Euclidean distance" << endl;
  cout << "      max: Maximum distance" << endl;
  cout << "  -e: Use delay embedding of dimension \'EDIM\'" << endl;
  cout << "      Note: only available for one-dimensional time series" << endl;
  cout << "  -f: Use floating point arithmetic for increased accuracy" << endl;
  cout << "  -h: Show this help text" << endl;
  cout << "  -i: Scale distances to have IDIGITS digits precision in integer-arithmetic (default: 5)" << endl;
  cout << "  -l: Optional specification of lag \'ELAG\' (default: 1) for delay embedding" << endl;
  cout << "  -m: Output average distance and standard deviation (when bootstrapping)." << endl;
  cout << "  -p: Use Wasserstein distance of order ORDER >= 1 (default = 1)" << endl;
  cout << "      Important special cases are the following:" << endl;
  cout << "      1  : Kantorovich-Rubinstein distance" << endl;
  cout << "      2  : Quadratic Wasserstein distance" << endl;
  cout << "  -r: Use 'random' seed for random numbers (only useful if bootstrapping)" << endl;
  cout << "  -s: Use resamples of SSIZE points from both sets (with replacement)" << endl;
  cout << "  -t: Use torus distances (wrapped from 0 to 2*Pi)" << endl;
  cout << "      Implies that all point coordinates are >= 0.0 and <= 2*Pi" << endl;
  cout << "  -v: Verbose output?" << endl;
  cout << "  -x: Extremely verbose output" << endl;
  cout << "  -w: Use probabilistic weights (last column of input files)" << endl;
  cout << endl;
  cout << "Details:" << endl;
  cout << "  The input files should contain the coordinates of each point per row," << endl;
  cout << "  separated by some whitespace. Optionally, the last entry can be interpreted" << endl;
  cout << "  as a (relative) probability. If these are all integers, they will be used" << endl;
  cout << "  directly in integer-arithmetic (see below), otherwise these will be normalized" << endl;
  cout << "  to sum to one." << endl;
  cout << "  The main concern here is speed and accuracy, especially for large datasets." << endl;
  cout << "  The fastest calculation should be possible for point sets of equal size, or" << endl;
  cout << "  when resampling (subsets of equal size SSIZE), since then integer arithmetic" << endl;
  cout << "  can be used (enabled by default). This makes it necessary to map the point-to-point" << endl;
  cout << "  distances to integers, however, with a certain loss of accuracy, and floating-point" << endl;
  cout << "  arithmetic can therefore be requested explicitly." << endl;
  cout << endl;
  cout << "References:" << endl;
  cout << "  The theory behind the Wasserstein distances can be found in:" << endl;
  cout << "    - Villani C. Topics in optimal transportation. American Mathematical Society (2003)." << endl;
  cout << "  The following articles consider its application to time series and to phase distributions:" << endl;
  cout << "    - Muskulus M, Verduyn-Lunel S. Wasserstein distances in the analysis of time series and dynamical" << endl;
  cout << "      systems. Physica D (2010), to appear." << endl;
  cout << "    - Muskulus M, Houweling S, Verduyn-Lunel S, Daffertshofer A. Functional similarities and distance" << endl;
  cout << "      properties. J Neurosci Meth 183 (2009), 31-31." << endl;
  cout << endl;
  cout << "Examples: " << endl;
  cout << "  Calculate Kantorovich-Rubinstein distance between two point sets" << endl;
  cout << "    " << argv[0] << " file1 file2" << endl;
  cout << "  Bootstrap distances 100 times with 512 sample points each" << endl;
  cout << "    " << argv[0] << " -b 100 -s 512 file1 file2" << endl;
  cout << "  Calculate distances between phases" << endl;
  cout << "    " << argv[0] << " -t file1 file2" << endl;
  cout << "  Use Manhattan distance for two weighted point sets, using 100 points each" << endl;
  cout << "    " << argv[0] << " -d l1 -s 100 -w file1 file2" << endl;
  exit(1);
};

//
// parse_cmdline
//

void parse_cmdline(int argc, char **argv) {
  char c;
  stringstream arg1;
  string s;
  while ((c = getopt(argc, argv, "a:b:d:e:fhi:l:mp:rs:tvwx")) != -1)
    switch (c) {
    case 'a': g_write_dimacs = true; g_dfile = optarg; break;
    case 'b': g_bootstrap = true; arg1.str(optarg); arg1 >> g_ncalc; arg1.clear(); break;
    case 'd': 
      g_distance = dist_unknown;
      s = optarg;
      if (s == "l1") g_distance = dist_l1;
      if (s == "l2") g_distance = dist_l2;
      if (s == "max") g_distance = dist_max;
      if (g_distance == dist_unknown) {
	g_err = "Unknown distance \'" + s + "\' specified";
	show_error(g_err.c_str());
      };
      break;
    case 'e': g_use_embedding = true; arg1.str(optarg); arg1 >> g_edim; arg1.clear(); break;
    case 'f': g_integer_arithmetic = false; break;
    case 'h': show_help(argc, argv); break;
    case 'i': arg1.str(optarg); arg1 >> g_digits; arg1.clear(); 
      g_scaling = pow(10,g_digits);
      break;
    case 'l': arg1.str(optarg); arg1 >> g_elag; arg1.clear(); break;
    case 'm': g_output_mean = true; break;
    case 'p': arg1.str(optarg); arg1 >> g_order; arg1.clear(); break;
    case 'r': g_random_seed = true; break;
    case 's': g_resample = true; arg1.str(optarg); arg1 >> g_ssize; arg1.clear(); break;
    case 't': g_torus = true; break;
    case 'v': g_verbose = max(g_verbose,1); break;
    case 'x': g_verbose = 2; break;
    case 'w': g_use_weights = true; break;
    case '?': cout << "Unknown " << optopt << endl; break;
    default: exit(1);
    }
  // check for collisions
  if (g_elag != 1 && !g_use_embedding) show_error("Cannot use time lag without delay embedding");
  // get filenames
  if (argc-optind != 2) show_help(argc, argv);
  g_fname1 = argv[optind++]; 
  g_fname2 = argv[optind++]; 
};

//
// split_line
//

void split_line(const string& s, vector<double>& v) {
  v.clear();
  double d;
  stringstream ss;
  if (s.empty()) return;
  string s1 = s;
  const char* delim = " ;\t"; // delimiters (whitespace)
  // trim the beginning of the line
  string::size_type i1;
  string::size_type i2 = 0;
  string part;
  while (i2 != string::npos) {
    i1 = s1.find_first_not_of(delim);
    if (i1 == string::npos) return;
    if (s1.at(i1) == '#') return; // comment starts here
    i2 = s1.find_first_of(delim, i1+1);
    if (i2 == string::npos) i2 = s1.length();
    part = s1.substr(i1, i2-i1);
    s1 = s1.substr(i2,s1.length()-i2);
    ss.clear();
    ss.str(part);
    ss >> d;
    v.push_back(d);
  };
};

//
// read_file
//

void read_file(string fname, int& dim, vector<point_type*> &list,
	       vector<double> &mass) {
  string cl;        // current line
  vector<double> v; // current line contents
  double m;         // probability mass
  ifstream ifs(fname.c_str(), ifstream::in);
  if (!ifs.good()) {
    g_err = "Input file \'" + fname + "\' does not exist or is empty";
    show_error(g_err.c_str());
  };
  // get first line and split it into numerical entries
  getline(ifs,cl);
  split_line(cl,v);
  if (g_use_weights) { // last column contains weights
    if (dim > 0 && int(v.size()) != dim+1) show_error("Dimensions (no. columns - 1) of the two files need to match");
    if (dim == 0 && g_verbose) cout << "Dimension = " << v.size() - 1 << endl; 
    dim = v.size() - 1;
 } else {
    if (dim > 0 && int(v.size()) != dim) show_error("Dimensions (no. columns) of the two files need to match");
    if (dim == 0 && g_verbose) cout << "Dimension = " << v.size() << endl;
    dim = v.size();
  };
  m = 1.0;
  if (g_use_weights) {
    m = v[v.size()-1];
    v.erase(v.end()-1);
  };
  mass.push_back(m);
  point_type *v1 = new point_type(v);
  list.push_back(v1);
  if (g_torus) for (unsigned int i=0; i<v.size(); ++i) {
    if (v[i] >= 2.0*M_PI) show_error("Torus distances enabled, but found coordinate >= 2*pi");
    if (v[i] <  0.0)      show_error("Torus distances enabled, but found coordinate < 0");
  };
  while (ifs.good()) {
    getline(ifs,cl);
    split_line(cl,v);
    // check for empty line
    if (v.size() == 0) continue;
    if (g_torus) for (unsigned int i=0; i<v.size(); ++i) {
      if (v[i] >= 2.0*M_PI) show_error("Torus distances enabled, but found coordinate >= 2*pi");
      if (v[i] <  0.0)      show_error("Torus distances enabled, but found coordinate < 0");
    };
    m = 1.0;
    if (g_use_weights) {
      m = v[v.size()-1];
      v.erase(v.end()-1);
    };
    mass.push_back(m);
    if (v.size() != v1->size()) {
      g_err = "Dimensions of successive points (columns per row) in file " + fname + " need to match";
      show_error(g_err.c_str());
    };
    v1 = new point_type(v);
    list.push_back(v1);
  }
  if (g_verbose) cout << "Read " << list.size() << " points from file \'" + fname + "\'" << endl;

};

//
// start_rng, stop_rng
//

void start_rng() {
  const gsl_rng_type* T;
  gsl_rng_env_setup();  // choose random number generator from environment variables
  T = gsl_rng_default;
  g_rng = gsl_rng_alloc(T);
  if (g_random_seed) gsl_rng_set(g_rng, time(0));
  if (g_verbose) cout << "Using random generator type = " << gsl_rng_name(g_rng) << endl;
  if (g_verbose) cout << "Seed value = " << gsl_rng_default_seed << endl;
};

void stop_rng() {
  gsl_rng_free(g_rng);
};

//
// solve_lp
//

double solve_lp(vector<int> &ix1, vector<int> &ix2) {
  // copy into arrays (for easier interfacing)
  int nx = ix1.size();
  int ny = ix2.size();
  double* x;
  double* y;
  double* wx = new double[nx];
  double* wy = new double[ny];
  point_type *p;
  int i,j;
  int k = 0;
  double td;        // result
  int expected_x;  // expected memory
  int expected_y;  // expected memory
  if (g_use_weights && g_edim > 0) show_error("Cannot use weights with a delay embedding");
  if (g_dim != 1 && g_edim > 0) show_error("Cannot use multidimensional points with a delay embedding");
  if (g_edim > 0) {
    x = new double[nx*g_edim];
    y = new double[ny*g_edim];
    expected_x = nx*g_edim;
    expected_y = ny*g_edim;
  } else {
    x = new double[nx*g_dim];
    y = new double[ny*g_dim];
    expected_x = nx*g_dim;
    expected_y = ny*g_dim;
  };
  // first point set
  for (i=0; i<nx; ++i) {
    if (g_use_weights) wx[i] = g_mass1[ix1[i]];
    else wx[i] = 1.0;
    p = g_list1[ix1[i]];
    // cout << "write " << p->at(0) << endl;
    // cout << "new point; index = " << ix1[i] << endl;
    for (j=0; j<g_dim; ++j)
      x[k++] = p->at(j);
    // delay embedding? additional coordinates
    for (j=1; j<g_edim; ++j) {
      p = g_list1[ix1[i]+g_elag*j];
      // cout << "index = " << ix1[i] << " + " << g_elag*j << " -- size = " << g_list1.size() << endl;
      // cout << "  write " << p->at(0) << endl;
      x[k++] = p->at(0);
    };
  };
  // cout << "no. coordinates = " << k << endl;
  assert(k == expected_x);
  // second point set
  k = 0;
  for (i=0; i<ny; ++i) {
    if (g_use_weights) wy[i] = g_mass2[ix2[i]];
    else wy[i] = 1.0;
    p = g_list2[ix2[i]];
    // cout << "write " << p->at(0) << endl;
    for (j=0; j<g_dim; ++j)
      y[k++] = p->at(j);
    // delay embedding? additional coordinates
    for (j=1; j<g_edim; ++j) {
      p = g_list2[ix2[i]+g_elag*j];
      // cout << "  write " << p->at(0) << endl;
      y[k++] = p->at(0);
    };
  };
  assert(k == expected_y);
  if (g_integer_arithmetic) {
    int* wxi = new int[nx];
    int* wyi = new int[ny];
    // TODO: scale weights to sensible integers 
    // here: just collect the fractions and scale with some fixed factor
    double frac1 = 0.0;
    double frac2 = 0.0;
    int mass1 = 0;
    int mass2 = 0;
    for (i=0; i<nx; ++i) {
      wxi[i] = int(wx[i]);
      mass1 += wxi[i];
      frac1 += wx[i]-wxi[i];
    };
    if (g_verbose) cout << "Mass      #1 = " << mass1 << endl;
    if (g_verbose) cout << "Imbalance #1 = " << frac1 << endl;
    for (j=0; j<ny; ++j) {
      wyi[j] = int(wy[j]);
      mass2 += wyi[j];
      frac2 += wy[j]-wyi[j];
    }; 
    if (g_verbose) cout << "Mass      #2 = " << mass2 << endl;
    if (g_verbose) cout << "Imbalance #2 = " << frac2 << endl;
    if (mass1 == mass2) {
      if (g_verbose) cout << "Using integer-arithmetic" << endl;
      if (g_edim > 0) td = solve_gplk_int(g_edim,nx, x, wxi, ny, y, wyi, g_scaling, g_verbose);
      else td = solve_gplk_int(g_dim,nx, x, wxi, ny, y, wyi, g_scaling, g_verbose);
    } else {
      cerr << "Warning: Cannot use integer arithmetic with unbalanced weights (summing up to different totals)" << endl;
      cerr << "         Switching to floating-point arithmetic!" << endl;
      g_integer_arithmetic = false;
    };
    delete[] wxi;
    delete[] wyi;
  };
  if (!g_integer_arithmetic) {
    if (g_verbose) cout << "Using fixed-point-arithmetic" << endl;
    if (g_edim > 0) td = solve_gplk(g_edim,nx, x, wx, ny, y, wy, g_verbose);
    else td = solve_gplk(g_dim,nx, x, wx, ny, y, wy, g_verbose);
  };
  delete[] x;
  delete[] y;
  delete[] wx;
  delete[] wy;
  return td;
};

//
// main
//

int main(int argc, char **argv) {
  vector<int> ix1;    // indices of points to use, 1st point set
  vector<int> ix2;    // indices of points to use, 2nd point set
  int ssize1, ssize2; // sample sizes
  int rsize1, rsize2; // resample sizes (possibly different due to embedding)
  vector<double> tds; // results
  double td;          // single result
  parse_cmdline(argc, argv);
  // use integer arithmetic if equal size (and no floating-point arithmetic requested)
  if (g_integer_arithmetic)  // tentative: can we really use it?
    if (!g_resample && g_list1.size() != g_list2.size()) g_integer_arithmetic = false;  // impossible
  if (g_bootstrap) start_rng();
  read_file(g_fname1, g_dim, g_list1, g_mass1);
  read_file(g_fname2, g_dim, g_list2, g_mass2);
  if (g_verbose) cout << "Using Wasserstein distance of order = " << g_order << endl;
  for (int i=1; i<= g_ncalc; ++i) {  // bootstrapping loop
    ix1.clear();
    ix2.clear();
    if (g_bootstrap) { // implies resampling
      ssize1 = g_list1.size();
      ssize2 = g_list2.size();
      if (g_resample)
	ssize1 = ssize2 = g_ssize;
      rsize1 = ssize1;
      rsize2 = ssize2;
      // adjust for delay embedding
      if (g_edim > 0) rsize1 -= (g_edim-1)*g_elag;
      if (g_edim > 0) rsize2 -= (g_edim-1)*g_elag;
      ix1.reserve(ssize1);
      for (int i=0; i<ssize1; ++i) ix1.push_back(random_int(rsize1));
      ix2.reserve(ssize2);
      for (int j=0; j<ssize2; ++j) ix2.push_back(random_int(rsize2));     
    } else {
      rsize1 = g_list1.size();
      rsize2 = g_list2.size();
      // adjust for delay embedding
      if (g_edim > 0) rsize1 -= (g_edim-1)*g_elag;
      if (g_edim > 0) rsize2 -= (g_edim-1)*g_elag;
      ix1.reserve(rsize1);
      for (int i=0; i<rsize1; ++i) ix1.push_back(i);
      ix2.reserve(rsize2);
      for (int j=0; j<rsize2; ++j) ix2.push_back(j);
    };
    // main computation
    td = solve_lp(ix1,ix2); 
    // 
    if (g_verbose) cout << "\nWasserstein distance\n  ==> ";
    if (g_verbose || !g_output_mean) cout << td;
    tds.push_back(td);
    if (g_verbose) cout << " <==";
    if (g_verbose || !g_output_mean) cout << endl;
  };
  if (g_bootstrap) stop_rng();
  if (g_output_mean) {
    double mean = 0.0;  // sum
    double sd   = 0.0;    // sum of squares
    for (unsigned int i=0; i<tds.size(); ++i) {
      mean += tds[i];
      sd   += tds[i]*tds[i];
    };
    mean /= tds.size();
    sd    = sd/tds.size() - mean*mean;
    if (g_verbose) cout << "\nWasserstein distance (average +/- SD) \n  ==> ";
    cout << mean << " ";
    if (g_verbose) cout << " (+/- ";
    cout << sd;
    if (g_verbose) cout << ") <==";
    cout << endl;
  };
  // clean-up
  for (unsigned int i=0; i<g_list1.size(); ++i) {
    point_type* v = g_list1[i];
    delete v;
  };
  for (unsigned int i=0; i<g_list2.size(); ++i) {
    point_type* v = g_list2[i];
    delete v;
  };
 
 
}
